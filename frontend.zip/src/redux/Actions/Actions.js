export const Actions = {
  USERLOGIN: "USERLOGIN",
  LOGIN_FAILURE: "LOGIN_FAILURE",
  LOGOUT: "LOGOUT",
   
};
export default {};
